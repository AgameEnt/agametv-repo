import xbmc

def logoff():
	xbmc.executebuiltin("Quit")

xbmc.log("uoool screen saver has started .................", xbmc.LOGERROR)
if not xbmc.Player().isPlayingAudio():
	logoff()